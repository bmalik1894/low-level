/*
 * C program for Conway's ``game of life'', version to generate board
 * using srand() and rand().
 *
 * FIXME more here
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

#include "game-of-life-util.h"

/* 
 * main program
 */
int main(int argc, char* argv[]) {
    /* FIXME your code goes here */
	return EXIT_SUCCESS;
}

